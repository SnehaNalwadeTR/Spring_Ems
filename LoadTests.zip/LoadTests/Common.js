let papaparse = require("./Metadata/lib/papaparse.js");
import { sleep, fail } from "k6";

module.exports = {
   getRandomAmount(min, max) {
      return Math.floor(Math.random() * (max - min + 1)) + min;
   },

   getRandomIndex(lengthOfArray) {
      return Math.floor(Math.random() * (lengthOfArray - 1));
   },

   randomizeArray(array) {
      array.sort(() => Math.random() - Math.random()).slice(0, 4);
      return array;
   },
   getParamsForServices(firm, account) {
      return {
         timeout: 600000,
         headers: {
            Accept: "application/hal+json",
            "Content-Type": "application/json",
            Account: firm,
            Firm: "TTAX",
            // "X-LoneStar-Product-FirmId": firm,
            // "X-LoneStar-AccountId": account,
         },
         tags: {
            name: "",
         },
      };
   },
   simulateUserDelay() {
      sleep(1 + Math.random());
   },
   /**
    *
    * @param {string} scenarioName
    * @param {*} data
    */
   logFailure(binderId, data, hardStop = false) {
      let message = "";

      if (binderId != null) {
         message = "FAILED IN SCENARIO " + data.url + "_" + data.serviceDetails.method + "STATUS CODE: " + data.status + " BinderID : " + binderId;
      } else {
         message = "FAILED IN SCENARIO " + data.url + "_" + data.serviceDetails.method + "STATUS CODE: " + data.status;
      }

      //console.log(message);
      console.log(`/**********************************************************
                        RESULT :-
                       URL:-  ${data.url}
                       StatusCode:- ${data.status}                      
                       **********************************************************/`);

      if (hardStop == true) {
         fail(message);
      }
   },

   /**
    *
    * @param {*} eorgs
    */
   generateBulkGetForEOrgs(eorgs) {
      var payload = [
         {
            InterestingFieldMatch: {},
            BulkDataFields: [],
         },
      ];
      eorgs.forEach((x) => {
         payload[0].BulkDataFields.push({ Eorg: x });
      });
      return JSON.stringify(payload);
   },
   generateBulkPutForEOrgs(eorgs) {
      var payload = [
         {
            InterestingFieldMatch: {},
            BulkDataFields: [],
         },
      ];
      eorgs.forEach((x) => {
         payload[0].BulkDataFields.push({ Eorg: x.split("=")[0], DataString: Math.round(Math.random() * 10000) });
      });
      return JSON.stringify(payload);
   },
   /**
    *
    * @returns
    */
   getSimpleParams() {
      return {
         timeout: 600000,
         headers: config.simpleHeaders,
         tags: {
            name: "",
         },
      };
   },
   getTestData(env, account) {
      return papaparse.parse(open(`../TestData/ExcelDriven/${env}/${account}.csv`), { header: true });
   },
};
