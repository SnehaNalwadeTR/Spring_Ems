const fs = require("fs");
const _ = require("lodash");
const csv = require("fast-csv");
let config = require("../Configuration.json");
const request = require("sync-request");
let template = require("./template.json");
const arrTopConBinders = require("./TestData/" + config.Environment + "/" + config.Account);
const arrActions = ["putCalls", "getScreenData", "runFederalEfile", "runStateEfile", "runEfileErrorCheck", "runWebPrint", "runDiagnostics", "runTASCompute", "Dccalls"];
//const arrActions = ["runWebPrint"];
const arrCreds = require("./config.json")[config.Environment][config.Account];

let finalData = new Array();
//User name and password should be updated in the configuration.json file as well.
let token = request("POST", config[config.Environment].BASEURL + "/" + config[config.Environment].authenv + "/home-security/api/security/v1/sessions/fromusermodel/", {
   json: {
      username: config[config.Environment].user.username,
      password: config[config.Environment].user.password,
   },
});

_.forEach(arrTopConBinders, (tcbinder) => {
   template.workareaId = tcbinder.workareaId;
   template.WorkAreaName = tcbinder.WorkAreaName;
   let temp = _.cloneDeep(template);
   let tcCreds = arrCreds[Math.floor(Math.random() * arrCreds.length)];
   temp.firm = tcbinder.binderLocatorId.substr(0, 4);
   temp.username = tcCreds.username;
   temp.password = tcCreds.password;

   temp.runTASConsol = "TRUE";
   temp.Test = "runTASConsol";
   Object.keys(tcbinder).forEach((key) => {
      temp[key] = tcbinder[key];
   });
   delete temp.accountNum;
   temp.account = tcbinder.accountNum;
   finalData.push(temp);
   let res = request("GET", `${config[config.Environment].BASEURL}/oit/oit-binder/binders/${tcbinder.binderLocatorId}/memberAssignments`, {
      headers: {
         Authorization: `UDSLongToken ${JSON.parse(token.getBody("utf-8"))}`,
         Account: config.Account,
         //need to modify if we are using direct login user.Modify as config.Account
         // if we are using, TTAX keep it as is.
         Firm: "518K",
      },
   });

   _.forEach(JSON.parse(res.getBody("utf-8"))._embedded.memberassignments, (member) => {
      let temp = _.cloneDeep(template);
      temp.account = tcbinder.accountNum;
      let tempCreds = arrCreds[Math.floor(Math.random() * arrCreds.length)];
      temp.username = tempCreds.username;
      temp.password = tempCreds.password;
      temp.firm = tcbinder.binderLocatorId.substr(0, 4);
      temp.runTASConsol = "FALSE";
      let option = arrActions[Math.floor(Math.random() * arrActions.length)];
      temp[option] = "TRUE";
      temp.Test = option;

      temp.binderLocatorId = member.binderId;
      temp.entityTypeId = member.entityTypeId;
      temp.taxYear = member.year;
      let tempTaxType = member.binderTaxReturnTypeId == "1120C" ? "1120" : member.binderTaxReturnTypeId;
      temp.taxType = tempTaxType;
      temp.binderTaxReturnType = tempTaxType;
      let prefix = member.binderTaxReturnTypeId.includes("1120") ? "C" : "P";
      let suffix = member.year.toString().substr(3);
      temp.locatorId = `${prefix}${member.binderId.substr(10)}${suffix}`;
      finalData.push(temp);
   });
});

const ws = fs.createWriteStream("out.csv");
csv.write(finalData, { headers: true }).pipe(ws);
