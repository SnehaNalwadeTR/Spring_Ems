import { check } from "k6";
import http from "k6/http";
import { Counter, Trend } from "k6/metrics";
let config = JSON.parse(open("./Configuration.json"));
let svcs = JSON.parse(open("./Services.json"));
var common = require("./Common.js");
var jsonPath = require("./Metadata/lib/jsonpath.js");
// var svcs = require("./Services.json");
var env = __ENV.env ? __ENV.env : config.Environment;
var trends = {};
var passcounters = {};
var failcounters = {};
var overallPassed = new Counter("OverallPassed");
var overallFailed = new Counter("OverallFailed");
var NoOfLocatorsFailed = new Counter("ActualLocatorOpenFailures");
var actualOpenLocatorFailures = [];
Object.values(svcs).forEach((x) => {
   trends[x.name] = new Trend("TREND_" + x.name, true);
   passcounters[x.name] = new Counter("PassCount_" + x.name);
   failcounters[x.name] = new Counter("FailCount_" + x.name);
});
export class ServiceDetails {
   constructor() {
      this.name = "";
      this.baseUrl = "";
      this.method = "GET";
      this.dynamicValues = {};
      this.jsonResult = false;
      this.resultCollection = [];
      this.statusExpected = "200";
      this.selFromResponse = null;
      this.hardstop = false;
   }
}
export class Services {
   /**
    *
    * @param {ServiceDetails} svcDetails
    * @returns
    */
   actualUrl(svcDetails) {
      var prefix = svcDetails.baseUrl.split("/")[0];
      //console.log(JSON.stringify(config[env]));
      var baseUrl = svcDetails.baseUrl.replace(prefix, config[env][prefix]);
      Object.keys(config[env]).forEach((x) => (baseUrl = baseUrl.replace("${" + x + "}", config[env][x])));
      Object.keys(svcDetails.dynamicValues).forEach((x) => (baseUrl = baseUrl.replace("${" + x + "}", svcDetails.dynamicValues[x])));
      return baseUrl;
   }
   /**
    *
    * @param {ServiceDetails} svcDetails
    * @param {any} params
    * @param {any} body
    * @returns
    */
   MakeRequest(svcDetails, params, body = null, options = {}) {
      let toBeReturned = {};
      var url = this.actualUrl(svcDetails);
      var response = this.chooseServiceCall(svcDetails.method, url, params, body);
      var cookies = http.cookieJar();
      toBeReturned.cookies = cookies.cookiesForURL(response.url);
      //console.log(response.url + "=>" + response.status);
      toBeReturned.serviceDetails = svcDetails;
      toBeReturned.status = response.status;
      toBeReturned.url = response.url;
      toBeReturned.statusExpected = svcDetails.statusExpected;
      return this.responseAssertions(response, svcDetails, toBeReturned, options);
   }
   /**
    *
    * @param {any} response
    * @param {ServiceDetails} svcDetails
    * @param {*} toBeReturned
    * @returns
    */
   responseAssertions(response, svcDetails, toBeReturned, options) {
      try {
         if (
            !check(response, {
               [(svcDetails.statusExpected.includes(response.status) ? "" : __ENV.scenario + "==>") +
               (options.testName ? options.testName : svcDetails.name) +
               "_" +
               svcDetails.method +
               "- status " +
               response.status]: (r) => svcDetails.statusExpected.includes(r.status),
            }) ||
            response.status == 0
         ) {
            console.log(options.binderId);
            if ((options != null) & (options.binderId != null)) {
               if (svcDetails.name == "openLocator") {
                  console.log("OpenLocator Failed " + options.binderId);
                  if (!actualOpenLocatorFailures.includes(options.binderId)) {
                     actualOpenLocatorFailures.push(options.binderId);
                     NoOfLocatorsFailed.add(1);
                  }
               } else {
                  console.log(svcDetails.name + " Failed " + options.binderId);
               }
               common.logFailure(options.binderId, toBeReturned, svcDetails.hardstop);
            } else {
               common.logFailure(null, toBeReturned, svcDetails.hardstop);
            }
            failcounters[svcDetails.name].add(1);
            if (svcDetails.name != "getSession" && svcDetails.name != "deleteSession") {
               overallFailed.add(1);
               overallPassed.add(0);
            }
            trends[svcDetails.name].add(response.timings.duration, { service: svcDetails.name });
         } else {
            trends[svcDetails.name].add(response.timings.duration, { service: svcDetails.name });
            passcounters[svcDetails.name].add(1);
            overallPassed.add(1);
            overallFailed.add(0);
            if (svcDetails.jsonResult && response.status == 204) {
               toBeReturned[svcDetails.name + "_data"] = response.body;
            } else if (svcDetails.jsonResult && svcDetails.selFromResponse) {
               let result = jsonPath.query(response.json(), svcDetails.selFromResponse);
               toBeReturned[svcDetails.name + "_data"] = result.length > 0 ? (options && options.sendAll ? result : result[0]) : "";
            } else if (svcDetails.jsonResult) {
               toBeReturned[svcDetails.name + "_data"] = response.json();
            } else {
               toBeReturned[svcDetails.name + "_data"] = response.body;
            }
         }
      } catch (e) {
         failcounters[svcDetails.name].add(1);
         if (svcDetails.name != "getSession" && svcDetails.name != "deleteSession") {
            overallFailed.add(1);
            overallPassed.add(0);
         }
         console.log("status code for " + svcDetails.name + "_" + svcDetails.method + "=>" + response.status);
         console.log(e);
         console.log(options.binderId);
         if ((options != null) & (options.binderId != null)) {
            if (svcDetails.name == "openLocator") {
               console.log("OpenLocator Failed " + options.binderId);
               if (!actualOpenLocatorFailures.includes(options.binderId)) {
                  actualOpenLocatorFailures.push(options.binderId);
                  NoOfLocatorsFailed.add(1);
               }
            }
            common.logFailure(options.binderId, toBeReturned, svcDetails.hardstop);
         } else {
            common.logFailure(null, toBeReturned, svcDetails.hardstop);
         }
         toBeReturned[svcDetails.name + "_data"] = "";
      }
      return toBeReturned;
   }
   /**
    *
    * @param {String} method
    * @param {String} url
    * @param {any} params
    * @param {any} body
    * @returns
    */
   chooseServiceCall(method, url, params, body) {
      switch (method) {
         case "GET":
         default:
            return http.get(url, params);
         case "POST":
            return http.post(url, body, params);
         case "PUT":
            return http.put(url, body, params);
         case "PATCH":
            return http.patch(url, body, params);
         case "DELETE":
            return http.del(url, body, params);
      }
   }
}
