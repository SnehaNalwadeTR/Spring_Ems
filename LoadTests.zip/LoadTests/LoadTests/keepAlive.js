import { Services } from "../Services.js";
import http from "k6/http";
let svcConfig = JSON.parse(open("../Services.json"));
let config = JSON.parse(open("../Configuration.json"));
var apiCalls = new Services();
import { Counter } from "k6/metrics";
import { check, sleep } from "k6";
let keepAliveCnt = new Counter("KeepAlive");
let keepAliveResp = new Counter("KeepAliveResponses");
let keepAlive_Pass = new Counter("PassCount_keepAlive");
let keepAlive_Fail = new Counter("FailCount_keepAlive");
__ENV.env = __ENV.env ? __ENV.env : config.Environment;
__ENV.account = __ENV.account ? __ENV.account : config.Account;
var common = require("../Common.js");
export let options = {
   scenarios: {
      keepalive: {
         executor: "constant-vus",
         vus: 1,
         duration: "4h",
      },
   },
};
export default function () {
   console.log("in keep alive call");
   var response = apiCalls.MakeRequest(svcConfig.getSession, common.getSimpleParams()).getSession_data;
   // console.log(JSON.stringify(response));
   var sessions = response && response.hits && response.hits.hits ? response.hits.hits : [];
   // console.log(sessions.length);
   console.log("Keep Alive URL is " + config[__ENV.env].OTWBASEURL + "/locator/keepalive");
   var batchArray = [];
   if (sessions.length > 0) {
      sessions.forEach((x) => {
         keepAliveCnt.add(1);
         x._source.params.headers["cookie"] = `AWSALB=${x._source.cookies.AWSALB[0]}; AWSALBCORS=${x._source.cookies.AWSALBCORS[0]}`;
         batchArray.push(["GET", config[__ENV.env].OTWBASEURL + "/locator/keepalive", null, x._source.params]);
      });
      //console.log(JSON.stringify(batchArray));
      let responses = http.batch(batchArray);
      responses.forEach((x) => {
         keepAliveResp.add(1);
         console.log(x.status);
         if (
            !check(x, {
               ["keepAlive status " + x.status]: (r) => r.status == 200,
            })
         ) {
            console.log("keep alive failed");
            keepAlive_Fail.add(1);
         } else {
            console.log("keep alive passed");
            keepAlive_Pass.add(1);
         }
      });
   }
   sleep(0.4);
}
