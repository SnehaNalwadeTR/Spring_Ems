let config = JSON.parse(open("../Configuration.json"));
var common = require("../Common.js");
import { Services } from "../Services.js";
import http from "k6/http";
let svcConfig = JSON.parse(open("../Services.json"));
var apiCalls = new Services();

import { Scenarios } from "../Scenarios.js";
__ENV.env = __ENV.env ? __ENV.env : config.Environment;
__ENV.account = __ENV.account ? __ENV.account : config.Account;
var fileName = __ENV.testType ? __ENV.account + __ENV.testType : __ENV.account;
let testData = common.getTestData(__ENV.env, fileName);
//var vuData;
// export const options = {
//    discardResponseBodies: false,
//    scenarios: {
//       contacts: {
//          executor: "per-vu-iterations",
//          vus: 1,
//          iterations: 1,
//          maxDuration: "10m",
//       },
//    },
// };
export default function () {
   var vuData = testData.data[__VU - 1];
   var scenarios = new Scenarios(vuData, true);
   __ENV.scenario = vuData.binderLocatorId + "_" + vuData.Scenario;
   scenarios._init();
   scenarios.compute();
   scenarios.consolidate();
   scenarios.OITCalls();
   scenarios.BinderAdjustmentsGetAndPost();
   scenarios.DataConnectionCalls();
   scenarios.initializeLocator();
   scenarios.fullRecompute();
   scenarios.putCalls();
   scenarios.navigateScreens();
   //scenarios.getScreenData();
   scenarios.otwConsolidation();
   scenarios.createFederalEfile();
   scenarios.createStateEfile();
   scenarios.runDiagnostics();
   scenarios.efileErrorCheck();
   scenarios.print();
   scenarios.closeLocator();
}
export function teardown() {
   var response = apiCalls.MakeRequest(svcConfig.getSession, common.getSimpleParams()).getSession_data;
   //console.log(JSON.stringify(response));
   var sessions = response && response.hits && response.hits.hits ? response.hits.hits : [];
   //console.log(sessions.length);
   var batchArray = [];
   var deleteSession = [];
   if (sessions.length > 0) {
      sessions.forEach((x) => {
         x._source.params.headers["cookie"] = `AWSALB=${x._source.cookies.AWSALB[0]}; AWSALBCORS=${x._source.cookies.AWSALBCORS[0]}`;
         batchArray.push(["GET", config[__ENV.env].OTWBASEURL + "/v1/locator/close", null, x._source.params]);
         deleteSession.push(["DELETE", config[__ENV.env].SESSIONSERVICE + "/" + x._id, null, common.getSimpleParams()]);
      });
      //console.log(JSON.stringify(batchArray));
      let responses = http.batch(batchArray);
      responses.forEach((x) => {
         console.log(x.status);
      });
      responses = http.batch(deleteSession);
      responses.forEach((x) => {
         console.log("Delete Status" + x.status);
      });
   }
}
