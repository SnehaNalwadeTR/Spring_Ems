let config = JSON.parse(open("../Configuration.json"));
var common = require("../Common.js");

import { Scenarios } from "../Scenarios.js";
__ENV.env = __ENV.env ? __ENV.env : config.Environment;
__ENV.account = __ENV.account ? __ENV.account : config.Account;
let testData = common.getTestData(__ENV.env, __ENV.account);
export const options = {
   discardResponseBodies: false,
   scenarios: {
      contacts: {
         executor: "per-vu-iterations",
         vus: 1,
         iterations: 1,
         maxDuration: "10m",
      },
   },
};
export default function () {
   var vuData = testData.data[__VU - 1];
   var scenarios = new Scenarios(vuData, false);
   __ENV.scenario = vuData.binderLocatorId + "_" + vuData.Scenario;
   scenarios.gstInit();
   try {
      scenarios.fullRecompute();
      scenarios.putCalls();
      scenarios.navigateScreens();
      scenarios.otwConsolidation();
      scenarios.print();
      scenarios.createEfile_GST();
      // scenarios.createStateEfile();
      scenarios.createFederalEfile();
      scenarios.runDiagnostics();
      scenarios.efileErrorCheck();
      scenarios.closeLocator();
   } catch (error) {
      console.log("the script failed due to :" + error);
      scenarios.closeLocator();
   }
}
