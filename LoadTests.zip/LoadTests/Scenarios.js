import { VuData } from "./VuData.js";
let svcConfig = JSON.parse(open("./Services.json"));
var common = require("./Common.js");
import { Services } from "./Services.js";
var efilemetada = {};
efilemetada.GST_1040 = JSON.parse(open("./TestData/EfileMetaData_1040.json"))
var putCalls = {};
putCalls.GST_1120 = JSON.parse(open("./TestData/PutCalls_1120.json"));
putCalls.OIT_1120 = JSON.parse(open("./TestData/PutCalls_1120.json"));
putCalls.GST_1040 = JSON.parse(open("./TestData/PutCalls_1040.json"));
let config = JSON.parse(open("./Configuration.json"));
var dcPayload = open("./TestData/payload.Cx0");
var apiCalls = new Services();
import { check, sleep } from "k6";
import { Counter, Trend } from "k6/metrics";
var tasConsol = new Trend("TREND_TASConsol");
var tasCompute = new Trend("TREND_TASCompute");
var stateEfile = new Trend("TREND_StateEfile");
var fedEfile = new Trend("TREND_FedEfile");
var printConsolidatedTime = new Trend("TREND_printConsolidatedTime");
var eFileErrorCheck = new Trend("TREND_ErrorCheckEfile");
var efilePassCounters = new Counter("Pass_Efile");
var efileFailCounters = new Counter("Fail_Efile");
var PrintPassCounters = new Counter("Pass_Print");
var PrintFailCounters = new Counter("Fail_Print");
var diag = new Trend("TREND_Diagnostics");
var _ = require("./Metadata/lib/underscore/underscore.js");
var papaparse = require("./Metadata/lib/papaparse.js");
var screenData = {};
screenData.OIT_1120 = papaparse.parse(open("./TestData/1120ScreenData.csv"), { header: true }).data;
screenData.OIT_1065 = papaparse.parse(open("./TestData/1065ScreenData.csv"), { header: true }).data;
screenData.GST_1120 = papaparse.parse(open("./TestData/1120ScreenData_GST.csv"), { header: true }).data;
screenData.GST_1065 = papaparse.parse(open("./TestData/1065ScreenData_GST.csv"), { header: true }).data;
screenData.GST_1040 = papaparse.parse(open("./TestData/1040ScreenData_GST.csv"), { header: true }).data;
let consolData = JSON.parse(open("./TestData/consolidationMetadata.json"));
let efileData = JSON.parse(open("./TestData/EFileMetadata.json"));
var noOfRequests = 0;

export class Scenarios {
   /**
    *
    * @param {VuData} vuData
    * @param {*} isOneSource
    */
   constructor(vuData, isOneSource) {
      this.vuData = vuData;
      this.vuData.year = vuData.taxYear;
      this.vuData.isOneSource = isOneSource;
      this.params = common.getSimpleParams();
      this.otwparams = common.getSimpleParams();
      this.gstParams = common.getSimpleParams();
      this.application = this.vuData.isOneSource ? "OIT" : "GST";
   }
   /**
    * Calls only UDS Long token
    * @param {VuData} vuData
    */
   _init() {
      console.log("Initialization started for " + this.vuData.binderLocatorId + " For user id: " + this.vuData.username);
      var result = apiCalls.MakeRequest(svcConfig.udsLongToken, this.params, `{ username: "${this.vuData.username}", password: "${this.vuData.password}"}`);
      this.vuData.token = "UDSLongToken " + result.udsLongToken_data.replace(/\"/g, "");
      this.params = common.getParamsForServices(this.vuData.firm, this.vuData.account);
      this.params.headers["Authorization"] = this.vuData.token;
      this.vuData.params = this.params;
      console.log("Initialization Ended for " + this.vuData.binderLocatorId + " For user id: " + this.vuData.username);
   }
   /**
    * Data is configured only for PROD
    */
   putCalls() {
      if (this.vuData.putCalls == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         console.log("Starting Put Calls for " + this.vuData.binderLocatorId);
         let noOfPutCalls = 0;
         let tt = this.vuData.binderTaxReturnType.includes("1120") ? "1120" : this.vuData.binderTaxReturnType.includes("1065") ? "1065" : "1040";
         var putCallArray = common.randomizeArray(putCalls[this.application + "_" + tt]);
         // console.log("the putcall array value is:" + putCallArray);
         for (let i = 0; i < 1; i++) {
            putCallArray.forEach((x) => {
               svcConfig.organizerdata.dynamicValues = { area: x.area, screen: x.screen };
               apiCalls.MakeRequest(svcConfig.organizerdata, this.otwparams);
               svcConfig.updateScreenData.dynamicValues = { area: x.area, screen: x.screen };
               x.metadata.forEach((y) => {
                  y.value = common.getRandomAmount(10, 10000);
                  y["showClientValidationError"] = false;
                  y["clientValidationError"] = null;
                  y["isDirty"] = true;
                  noOfPutCalls++;
                  // console.log("Put Calls for eorg" + y["eorg"]);
                  //svc.Session.LogMessage(["Adding Put call for Eorg :" + y.eorg]);
                  apiCalls.MakeRequest(svcConfig.updateScreenData, this.otwparams, JSON.stringify(y));
                  sleep(3);
               });
            });
         } //for loop close
         apiCalls.MakeRequest(svcConfig.fullRecompute, this.otwparams, JSON.stringify({}));
         // svc.Session.LogMessage(["Done Executing PUT Calls"], { putCalls: noOfPutCalls });
         console.log("Completed Put calls for " + this.vuData.binderLocatorId);
      }
   }

   getBinderId() {
      if (this.vuData.binderLocatorId == "FALSE") {
         svcConfig.topConBinders.dynamicValues = {
            workAreaID: this.vuData.workareaId,
            year: this.vuData.taxYear,
            entityTypeId: this.vuData.entityTypeId,
            binderTaxReturnType: this.vuData.binderTaxReturnType,
         };
         var result = apiCalls.MakeRequest(svcConfig.topConBinders, this.params, null, { sendAll: true });
         this.vuData.binderLocatorId = result.topConBinders_data[0];
         this.vuData.bindeId = this.vuData.binderLocatorId;
      }
   }
   /**
    * Cookie blob generation
    * Open Locator
    */
   initializeLocator() {
      try {
         if (this.vuData.launchOTW == "TRUE") {
            console.log("Locator Initialization started for " + this.vuData.binderLocatorId);
            //get binder Id
            this.getBinderId();

            //CookieBlob call
            this.vuData.binderId = this.vuData.binderLocatorId;
            svcConfig.cookieBlob.dynamicValues = { binderId: this.vuData.binderId, binderTaxReturnType: this.vuData.binderTaxReturnType, year: this.vuData.taxYear };
            var result = apiCalls.MakeRequest(svcConfig.cookieBlob, this.params);
            // console.log("the cookie blob is : " + result.cookieBlob_data + " the product is : " + this.vuData.isOneSource);
            //open locator
            svcConfig.openLocator.dynamicValues = { openToken: result.cookieBlob_data, year: this.vuData.taxYear, isOneSource: this.vuData.isOneSource };
            delete this.otwparams.headers.Authorization;
            delete this.otwparams.headers["locator-token"];
            result = apiCalls.MakeRequest(svcConfig.openLocator, this.otwparams, null, { binderId: this.vuData.binderLocatorId });
            if (result.status != 200) {
               this.vuData.locatorClosed = "TRUE";
               console.log("OPEN_LOCATOR FAILED =>" + this.vuData.binderLocatorId);
            } else {
               this.vuData.locatorClosed = "FALSE";
            }
            this.vuData.AuthToken = result.openLocator_data.AuthToken;
            this.vuData.locatorToken = result.openLocator_data.Token;
            this.vuData.LocatorId = result.openLocator_data.LocatorId;
            this.otwparams.headers.Authorization = "Bearer " + this.vuData.AuthToken.replace(/\"/g, "");
            this.otwparams.headers["locator-token"] = this.vuData.locatorToken;
            svcConfig.createSession.dynamicValues = { vu: __VU };
            let payload = { params: this.otwparams, cookies: result.cookies };
            apiCalls.MakeRequest(svcConfig.createSession, common.getSimpleParams(), JSON.stringify(payload));
            console.log("Locator Initialization done for " + this.vuData.binderLocatorId);
         }
      } catch (ex) {
         this.vuData.locatorClosed = "TRUE";
      }
   }
   /* print with pdf preview call and preview refresh call*/
   printWithPreview() {
      var result;
      if (this.vuData.printCounts > 0 && this.vuData.runWebPrint == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         console.log("Print with preview Starting for " + this.vuData.binderLocatorId);
         //KeepAlive
         apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams, null, { sendAll: true });
         console.log(`this.vuData.printCounts => ${this.vuData.printCounts}`);
         console.log(`this.vuData.runWebPrint=>${this.vuData.runWebPrint}`);
         //print based on the number entered in Excel
         this.vuData.printCounts = this.vuData.printCounts > 0 ? this.vuData.printCounts : 0;
         var printJobs = [];
         for (let i = 0; i < this.vuData.printCounts; i++) {
            svcConfig.printReturn.dynamicValues = {
               pdfFileName: "TestPrint.pdf",
               area: this.vuData.binderTaxReturnType.includes("1120") ? 80 : this.vuData.binderTaxReturnType.includes("1040") ? 134 : 12,
            };
            result = apiCalls.MakeRequest(svcConfig.printReturn, this.otwparams);
            sleep(60);
            //console.log(JSON.stringify(result));
            printJobs.push(result.printReturn_data);
         }
         console.log(printJobs);
         //wait untilAllJobs are completed.
         let pending, failed, done;
         var startTime = new Date();
         do {
            pending = 0;
            failed = 0;
            done = 0;
            svcConfig.printJobHistory.dynamicValues = { locatorId: this.vuData.LocatorId };
            //Get the Job History
            result = apiCalls.MakeRequest(svcConfig.printJobHistory, this.otwparams);

            if (result.printJobHistory_data) {
               result.printJobHistory_data.Items.forEach((x) => {
                  //is Locator Dirty
                  svcConfig.isLocatorDirty.dynamicValues = { jobId: x.ID, taxApp: this.vuData.taxType, taxYear: this.vuData.taxYear };
                  let locDir = apiCalls.MakeRequest(svcConfig.isLocatorDirty, this.otwparams);

                  //check pending, failed and passed counts
                  if (x.Status.toLowerCase() != "done" && x.Status.toLowerCase() != "failed" && printJobs.includes(x.ID.toString())) {
                     pending++;
                  }
                  if (x.Status.toLowerCase() == "failed" && printJobs.includes(x.ID.toString())) {
                     failed++;
                  }
                  if (x.Status.toLowerCase() == "done" && printJobs.includes(x.ID.toString())) {
                     var endTime = new Date();
                     console.log("PrintConsolidatedTimeAdded" + ((endTime.getTime() - startTime.getTime()) / 1000).toFixed(2));
                     printConsolidatedTime.add(((endTime.getTime() - startTime.getTime()) / 1000).toFixed(2));
                     const index = printJobs.indexOf(x.ID.toString());
                     if (index > -1) {
                        printJobs.splice(index, 1);
                     }
                     printJobs.done++;
                     // go to preview page
                     svcConfig.PdfPreview.dynamicValues = { AuthToken: this.vuData.AuthToken.replace(/\"/g, ""), jobId: x.ID };

                     //Get the Job History
                     apiCalls.MakeRequest(svcConfig.PdfPreview, this.otwparams);
                     console.log("clicked on the pdf preview button " + this.vuData.binderLocatorId);
                     // refresh the preview page
                     svcConfig.PreviewRefresh.dynamicValues = { jobId: x.ID };
                     //Get the Job History
                     for (var i = 0; i < 5; i++) {
                        apiCalls.MakeRequest(svcConfig.PreviewRefresh, this.otwparams);
                        console.log("Pdf preview refresh done for: " + this.vuData.binderLocatorId);
                        sleep(30);
                     }
                  }
                  console.log(`${x.Locator}==>${x.ID} ==> ${x.Status}`);
               });
               //print counts
               console.log(`Pending-${pending} | Completed- ${done} | failed- ${failed} `);
            } else {
               console.log("FAILED TO GET PRINT JOB HISTORY");
            }
            sleep(1);
         } while (pending > 0); // do  while close
         console.log("Print Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * Print based on print count
    */
   print() {
      var result;
      if (this.vuData.printCounts > 0 && this.vuData.runWebPrint == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         console.log("Print Starting for " + this.vuData.binderLocatorId);
         //KeepAlive
         apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams, null, { sendAll: true });
         console.log(`this.vuData.printCounts => ${this.vuData.printCounts}`);
         console.log(`this.vuData.runWebPrint=>${this.vuData.runWebPrint}`);
         //print based on the number entered in Excel
         this.vuData.printCounts = this.vuData.printCounts > 0 ? this.vuData.printCounts : 0;
         var printJobs = [];
         for (let i = 0; i < this.vuData.printCounts; i++) {
            svcConfig.printReturn.dynamicValues = {
               pdfFileName: "TestPrint.pdf",
               area: this.vuData.binderTaxReturnType.includes("1120") ? 80 : this.vuData.binderTaxReturnType.includes("1040") ? 134 : 12,
            };
            result = apiCalls.MakeRequest(svcConfig.printReturn, this.otwparams);
            console.log("Print call is made ");
            sleep(30);
            //console.log(JSON.stringify(result));
            printJobs.push(result.printReturn_data);
            console.log("Print call result is pushed to the list ");
         }
         console.log(printJobs);
         //wait untilAllJobs are completed.
         let pending, failed, done;
         var startTime = new Date();
         do {
            pending = 0;
            failed = 0;
            done = 0;
            svcConfig.printJobHistory.dynamicValues = { locatorId: this.vuData.LocatorId };
            //Get the Job History
            result = apiCalls.MakeRequest(svcConfig.printJobHistory, this.otwparams);

            if (result.printJobHistory_data) {
               result.printJobHistory_data.Items.forEach((x) => {
                  //is Locator Dirty
                  svcConfig.isLocatorDirty.dynamicValues = { jobId: x.ID, taxApp: this.vuData.taxType, taxYear: this.vuData.taxYear };
                  let locDir = apiCalls.MakeRequest(svcConfig.isLocatorDirty, this.otwparams);

                  //check pending, failed and passed counts
                  if (x.Status.toLowerCase() != "done" && x.Status.toLowerCase() != "failed" && printJobs.includes(x.ID.toString())) {
                     pending++;
                  }
                  if (x.Status.toLowerCase() == "failed" && printJobs.includes(x.ID.toString())) {
                     failed++;
                     PrintFailCounters.add(1);
                  }
                  if (x.Status.toLowerCase() == "done" && printJobs.includes(x.ID.toString())) {
                     var endTime = new Date();
                     console.log("PrintConsolidatedTimeAdded" + ((endTime.getTime() - startTime.getTime()) / 1000).toFixed(2));
                     printConsolidatedTime.add(((endTime.getTime() - startTime.getTime()) / 1000).toFixed(2));
                     const index = printJobs.indexOf(x.ID.toString());
                     if (index > -1) {
                        printJobs.splice(index, 1);
                     }
                     printJobs.done++;
                     PrintPassCounters.add(1);
                  }
                  console.log(`${x.Locator}==>${x.ID} ==> ${x.Status}`);
               });
               //print counts
               console.log(`Pending-${pending} | Completed- ${done} | failed- ${failed} `);
            } else {
               console.log("FAILED TO GET PRINT JOB HISTORY");
            }
            sleep(1);
         } while (pending > 0); // do  while close
         console.log("Print Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * Go to screen and get the grid data and navigate to other screens
    */
   getScreenDataWithGridInfo() {
      if (this.vuData.getScreenData == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         console.log("Get SCreen Information started for " + this.vuData.binderLocatorId);
         try {
            let tt = this.vuData.binderTaxReturnType.includes("1120") ? "1120" : this.vuData.binderTaxReturnType.includes("1065") ? "1065" : "1040";
            var randomizedArray = common.randomizeArray(screenData[this.application + "_" + tt]);
            let j = 0;
            for (let i = 0; i < randomizedArray.length && j < 200; i++) {
               if (randomizedArray[i].area && randomizedArray[i].screen) {
                  let screenData = { area: randomizedArray[i].area, screen: randomizedArray[i].screen };
                  let navTreeData = { area: randomizedArray[i].area, screen: randomizedArray[i].screen };
                  //navTree
                  svcConfig.navtree.dynamicValues = { area: navTreeData.area, screen: navTreeData.screen };
                  apiCalls.MakeRequest(svcConfig.navtree, this.otwparams);
                  //otwScreenData
                  svcConfig.otwScreenData.dynamicValues = { area: screenData.area, screen: screenData.screen };
                  apiCalls.MakeRequest(svcConfig.otwScreenData, this.otwparams);
                  j++;
               }
            }
         } catch (ex) {
            console.log(ex);
            console.log("ERROR OCCURED GETTING THE DATA FOR SCREENS");
         }
         console.log("Get Screen INformation Completed for " + this.vuData.binderLocatorId);
      }
   }


   /**
    * Consolidate Binder
    */
   consolidate() {
      if (this.vuData.runTASConsol == "TRUE") {
         console.log("Consolidation started for " + this.vuData.binderLocatorId);
         //get binderId
         this.getBinderId();

         //TAS Consolidation
         let payload = `{ consolidationDepth: 2, includeRelatedPartnership: false, includeRelatedForeignMember: false, refreshHistoricalBalances: false }`;
         svcConfig.consolidationStatus.dynamicValues = { binderId: this.vuData.binderLocatorId };
         let result = apiCalls.MakeRequest(svcConfig.consolidationStatus, this.params);
         let startTime = new Date();

         //check if Binder is ready / Compute never finished
         if (
            result.consolidationStatus_data.statusMessage.toLowerCase().indexOf("ready") > -1 ||
            result.consolidationStatus_data.statusMessage.toLowerCase().indexOf("compute never finished") > -1
         ) {
            svcConfig.tasConsolidate.dynamicValues = { binderId: this.vuData.binderLocatorId };
            //Trigger Consolidate
            apiCalls.MakeRequest(svcConfig.tasConsolidate, this.params, payload);
         }

         //Poll Consolidation Status
         do {
            result = apiCalls.MakeRequest(svcConfig.consolidationStatus, this.params);
            if (!result.consolidationStatus_data.statusMessage) {
               result.consolidationStatus_data.statusMessage = "";
            }
         } while (
            result.consolidationStatus_data.statusMessage.toLowerCase().indexOf("ready") == -1 &&
            result.consolidationStatus_data.statusMessage.toLowerCase().indexOf("compute never finished") == -1
         );
         let endTime = new Date();
         //record timings for consolidation
         tasConsol.add(((endTime.getTime() - startTime.getTime()) / 1000).toFixed(2));
         console.log("Consolidation Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * Compute Binder
    */
   compute() {
      if (this.vuData.runTASCompute == "TRUE") {
         console.log("Compute started for " + this.vuData.binderLocatorId);
         svcConfig.tasCompute.dynamicValues = { binderId: this.vuData.binderLocatorId };
         svcConfig.computeStatus.dynamicValues = { binderId: this.vuData.binderLocatorId };
         let startTime = new Date();
         var result = apiCalls.MakeRequest(svcConfig.computeStatus, this.params);

         //Check if status is ready / Compute never finished
         if (
            result.computeStatus_data.statusMessage.toLowerCase().indexOf("ready") > -1 ||
            result.computeStatus_data.statusMessage.toLowerCase().indexOf("compute never finished") > -1
         ) {
            result = apiCalls.MakeRequest(svcConfig.tasCompute, this.params, null);
         }

         //Poll Compute Status
         do {
            result = apiCalls.MakeRequest(svcConfig.computeStatus, this.params);
            if (!result.computeStatus_data.statusMessage) {
               result.computeStatus_data.statusMessage = "";
            }
         } while (
            result.computeStatus_data.statusMessage.toLowerCase().indexOf("ready") == -1 &&
            result.computeStatus_data.statusMessage.toLowerCase().indexOf("compute never finished") == -1
         );
         let endTime = new Date();

         //record timings for consolidation
         tasCompute.add((endTime.getTime() - startTime.getTime()).toFixed(2));
         console.log("Compute Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * All OIT API Calls
    */
   OITCalls() {
      if (this.vuData.oitGetAPICalls == "TRUE") {
         console.log("OIT Calls started for " + this.vuData.binderLocatorId);
         //usIncomeTax
         _.times(config.OITServiceCounts.getUSIncomeTax, () => apiCalls.MakeRequest(svcConfig.usIncomeTax, this.params));
         //getUserBinders
         _.times(config.OITServiceCounts.getUserBinders, () => apiCalls.MakeRequest(svcConfig.userBinders, this.params));
         //getPlatformEntitiesSummary
         apiCalls.MakeRequest(svcConfig.platformEntitiesSummary, this.params);
         //getCommonEntityBetaAccounts
         apiCalls.MakeRequest(svcConfig.commonEntityBetaAccounts, this.params);
         //getBinderYears
         _.times(config.OITServiceCounts.getBinderYears, () => apiCalls.MakeRequest(svcConfig.binderYears, this.params));
         //getAvailableTaxYear
         apiCalls.MakeRequest(svcConfig.availableTaxYear, this.params);
         //getWorkareas
         _.times(config.OITServiceCounts.getWorkareas, () => apiCalls.MakeRequest(svcConfig.workareas, this.params));
         //getBinderTags
         svcConfig.binderTags.dynamicValues = { workAreaID: this.vuData.workareaId };
         _.times(config.OITServiceCounts.getBinderTags, () => apiCalls.MakeRequest(svcConfig.binderTags, this.params));
         //getEfileWorkpapers
         svcConfig.eFileWorkpaper.dynamicValues = { binderId: this.vuData.binderLocatorId };
         apiCalls.MakeRequest(svcConfig.eFileWorkpaper, this.params);
         //getBinderGroupYears
         apiCalls.MakeRequest(svcConfig.binderGroupYears, this.params);
         //getBatch Summaries
         svcConfig.batchSummaries.dynamicValues = { year: this.vuData.taxYear };
         apiCalls.MakeRequest(svcConfig.batchSummaries, this.params);
         //getEfileStatus
         svcConfig.eFileStatus.dynamicValues = { year: this.vuData.taxYear };
         apiCalls.MakeRequest(svcConfig.eFileStatus, this.params);
         //getScheduleM3Chart
         svcConfig.scheduleM3Chart.dynamicValues = {
            year: this.vuData.taxYear,
            taxReturnType: this.vuData.binderTaxReturnType == "1120" ? "1120C" : this.vuData.binderTaxReturnType,
         };
         apiCalls.MakeRequest(svcConfig.scheduleM3Chart, this.params);
         //getTCCChart
         apiCalls.MakeRequest(svcConfig.tccCharts, this.params);
         //getFCOAChart
         apiCalls.MakeRequest(svcConfig.fcoaCharts, this.params);

         //getWTBWorkpaper
         svcConfig.wtbWorkpaper.dynamicValues = { binderId: this.vuData.binderLocatorId };
         apiCalls.MakeRequest(svcConfig.wtbWorkpaper, this.params);
         //pollTasConsolStatus
         if (this.vuData.runTASConsol == "TRUE") {
            svcConfig.consolidationStatus.dynamicValues = { binderId: this.vuData.binderLocatorId };
            _.times(config.OITServiceCounts.pollTasConsolStatus, () => apiCalls.MakeRequest(svcConfig.consolidationStatus, this.params));
         }
         //pollComputeStatus
         if (this.vuData.runTASCompute == "TRUE") {
            svcConfig.computeStatus.dynamicValues = { binderId: this.vuData.binderLocatorId };
            _.times(config.OITServiceCounts.pollComputeStatus, () => apiCalls.MakeRequest(svcConfig.computeStatus, this.params));
         }
         //getBinderDetails
         svcConfig.binderDetails.dynamicValues = { binderId: this.vuData.binderLocatorId };
         _.times(config.OITServiceCounts.getBinderDetails, () => apiCalls.MakeRequest(svcConfig.binderDetails, this.params));
         //getBinderModules
         svcConfig.binderModules.dynamicValues = { binderId: this.vuData.binderLocatorId };
         _.times(config.OITServiceCounts.getBinderModules, () => apiCalls.MakeRequest(svcConfig.binderModules, this.params));
         //binderInitializations
         svcConfig.binderInitializations.dynamicValues = { binderId: this.vuData.binderLocatorId };
         _.times(config.OITServiceCounts.binderInitializations, () => apiCalls.MakeRequest(svcConfig.binderInitializations, this.params));
         //getBinderSummary
         svcConfig.binderSummary.dynamicValues = { binderId: this.vuData.binderLocatorId };
         _.times(config.OITServiceCounts.getBinderSummary, () => apiCalls.MakeRequest(svcConfig.binderSummary, this.params));
         //getTaxReturnEvents
         svcConfig.taxReturnEvents.dynamicValues = { binderId: this.vuData.binderLocatorId };
         _.times(config.OITServiceCounts.getTaxReturnEvents, () => apiCalls.MakeRequest(svcConfig.taxReturnEvents, this.params));
         //getWorkingTrialBalanceForms
         svcConfig.workingTrialBalanceForms.dynamicValues = { binderId: this.vuData.binderLocatorId };
         _.times(config.OITServiceCounts.getWorkingTrialBalanceForms, () => apiCalls.MakeRequest(svcConfig.workingTrialBalanceForms, this.params));
         //getWorkingTrialBalance
         svcConfig.workingTrialBalance.dynamicValues = { binderId: this.vuData.binderLocatorId };
         apiCalls.MakeRequest(svcConfig.workingTrialBalance, this.params);
         //getWorkingTrialBalanceCurrencies
         svcConfig.workingTrialBalanceCurrencies.dynamicValues = { binderId: this.vuData.binderLocatorId };
         apiCalls.MakeRequest(svcConfig.workingTrialBalanceCurrencies, this.params);
         //getImportStatusLog
         svcConfig.importStatusLog.dynamicValues = { year: this.vuData.taxYear };
         apiCalls.MakeRequest(svcConfig.importStatusLog, this.params);
         //getEntities
         svcConfig.entities.dynamicValues = { workAreaID: this.vuData.workareaId };
         apiCalls.MakeRequest(svcConfig.entities, this.params);
         //getHasPermission
         svcConfig.hasPermission.dynamicValues = { objectId: "123", permissionId: "123" };
         apiCalls.MakeRequest(svcConfig.hasPermission, this.params);
         //getChartAssignment
         svcConfig.chartAssignments.dynamicValues = { binderId: this.vuData.binderLocatorId };
         apiCalls.MakeRequest(svcConfig.chartAssignments, this.params);
         console.log("OIT Calls Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * BinderAdjustments and balances get and post
    */
   BinderAdjustmentsGetAndPost() {
      if (this.vuData.runBalAdjGetAndPost == "TRUE") {
         //getBinderPreliminaryBalances
         console.log("Binder Adjustment Calls started for " + this.vuData.binderLocatorId);
         svcConfig.binderPreliminaryBalances.dynamicValues = { binderId: this.vuData.binderLocatorId };
         let result = apiCalls.MakeRequest(svcConfig.binderPreliminaryBalances, this.params);
         let spliceValue = result.binderPreliminaryBalances_data.length / 3;
         let binderPreliminaryBalances = result.binderPreliminaryBalances_data.slice(0, Math.ceil(spliceValue));
         if (binderPreliminaryBalances && binderPreliminaryBalances.length > 0) {
            binderPreliminaryBalances.map((x) => {
               delete x.activityName;
               delete x.activityNumber;
               delete x._embedded;
               x.balance = Math.floor(Math.random() * 10000);
            });
            //ResetBinderPreliminaryBalances
            svcConfig.resetBinderPreliminaryBalances.dynamicValues = { binderId: this.vuData.binderLocatorId };
            apiCalls.MakeRequest(svcConfig.resetBinderPreliminaryBalances, this.params, {});
            //UpdatePreliminaryBalances
            svcConfig.updateBinderPreliminaryBalances.dynamicValues = { binderId: this.vuData.binderLocatorId };
            apiCalls.MakeRequest(svcConfig.updateBinderPreliminaryBalances, this.params, binderPreliminaryBalances);
         }
         //getBinderAdjustments
         svcConfig.binderAdjustments.dynamicValues = { binderId: this.vuData.binderLocatorId };
         let binderAdjustments = apiCalls.MakeRequest(svcConfig.binderAdjustments, this.params);
         if (binderAdjustments && binderAdjustments.length > 0) {
            binderAdjustments.map((x) => {
               x.adjustments.map((adj) => {
                  if (adj.accounts && adj.accounts.length > 1) {
                     let amount = Math.floor(Math.random() * 121);
                     adj.accounts[0].accountBalance = amount;
                     adj.accounts[adj.accounts.length - 1].accountBalance = 0 - amount;
                  }
               });
               delete x._embedded;
            });
            //resetBinderAdjustments
            svcConfig.resetBinderAdjustments.dynamicValues = { binderId: this.vuData.binderLocatorId };
            apiCalls.MakeRequest(svcConfig.resetBinderAdjustments, this.params, {});
            //updateBinderAdjustments
            svcConfig.updateBinderAdjustments.dynamicValues = { binderId: this.vuData.binderLocatorId };
            apiCalls.MakeRequest(svcConfig.updateBinderAdjustments, this.params, binderAdjustments);
         }
         console.log("Binder Adjustment Calls Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * DataConnection Calls
    */
   DataConnectionCalls() {
      if (this.vuData.Dccalls == "TRUE") {
         console.log("Data Connection Calls started for " + this.vuData.binderLocatorId);
         //DCImport
         svcConfig.DcImport.dynamicValues = { binderId: this.vuData.binderLocatorId };
         var dcCallsParams = JSON.parse(JSON.stringify(this.params));
         dcCallsParams.headers["Content-Type"] = "application/octet-stream";
         let result = apiCalls.MakeRequest(svcConfig.DcImport, dcCallsParams, dcPayload.replace("<BINDERID>", this.vuData.locatorId.substring(1, 7)));
         let processesId = result.DcImport_data.split("=")[1].replace(/\"/g, "");
         //PollDataConnectionStatus
         _.times(20, () => {
            svcConfig.DCPoolstatus.dynamicValues = { processesID: processesId, year: this.vuData.taxYear };
            apiCalls.MakeRequest(svcConfig.DCPoolstatus, this.params);
            sleep(2);
         });
         //DCExport
         svcConfig.DcExport.dynamicValues = { binderId: this.vuData.binderLocatorId };
         apiCalls.MakeRequest(svcConfig.DcExport, this.params, null);
         //PollDataConnectionStatus
         _.times(20, () => {
            svcConfig.DCPoolstatus.dynamicValues = { processesID: processesId, year: this.vuData.taxYear };
            apiCalls.MakeRequest(svcConfig.DCPoolstatus, this.params);
            sleep(2);
         });
         console.log("Data Connection Calls Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * Get Screen data- Sneha updated this to verify the uber issue
    */
   getScreenData() {
      if (this.vuData.getScreenData == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         console.log("Get SCreen Information started for " + this.vuData.binderLocatorId);
         try {
            let tt = this.vuData.binderTaxReturnType.includes("1120") ? "1120" : this.vuData.binderTaxReturnType.includes("1065") ? "1065" : "1040";
            var randomizedArray = common.randomizeArray(screenData[this.application + "_" + tt]);
            let j = 0;
            for (let k = 0; k < 100; k++) {
               for (let i = 0; i < randomizedArray.length && j < 200; i++) {
                  console.log(randomizedArray[i].area + " and " + randomizedArray[i].screen);
                  if (randomizedArray[i].area && randomizedArray[i].screen) {
                     let screenData = { area: randomizedArray[i].area, screen: randomizedArray[i].screen };
                     let navTreeData = { area: randomizedArray[i].area, screen: randomizedArray[i].screen };
                     //navTree
                     svcConfig.navtree.dynamicValues = { area: navTreeData.area, screen: navTreeData.screen };
                     apiCalls.MakeRequest(svcConfig.navtree, this.otwparams);
                     //otwScreenData
                     svcConfig.otwScreenData.dynamicValues = { area: screenData.area, screen: screenData.screen };
                     apiCalls.MakeRequest(svcConfig.otwScreenData, this.otwparams);
                     let memIds = [];
                     if (screenData.area == 1 && screenData.screen == 601) {

                        svcConfig.getGridData.dynamicValues = { area: screenData.area, screen: screenData.screen };
                        var result = apiCalls.MakeRequest(svcConfig.getGridData, this.otwparams);
                        result.getGridData_data.forEach((x) => {
                           memIds.push(x.col_1.origValue);
                        });
                        console.log("The grid data call is done");
                        console.log(memIds[0]);
                        var bindeId = this.vuData.binderId;
                        console.log(this.vuData.ExpectedLocators);

                        var value = check(result, {
                           [bindeId + " The locator value in the grid is matched "]: (x) => memIds[0] == this.vuData.ExpectedLocators
                        });
                        console.log("the value is :" + value);
                     }
                     j++;
                  }
               }
            }
         } catch (ex) {
            console.log(ex);
            console.log("ERROR OCCURED GETTING THE DATA FOR SCREENS");
         }
         console.log("Get Screen INformation Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * OTWConsolidation
    */
   otwConsolidation() {
      if (this.vuData.executeConsol == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         console.log("OTW Consolidation started for " + this.vuData.binderLocatorId);
         let taxReturnType = this.vuData.binderTaxReturnType.includes("1120") ? "1120" : "1065";
         var metadata = consolData[this.application][taxReturnType];
         //visit OTW screen to consolidate
         svcConfig.getScreenData.dynamicValues = { area: metadata.area, screen: metadata.screen };
         apiCalls.MakeRequest(svcConfig.getScreenData, this.otwparams);
         //run the consolidation by running executeCommand
         svcConfig.executeCommand.dynamicValues = { area: metadata.area, screen: metadata.screen, field: metadata.script, command1: 0 };
         apiCalls.MakeRequest(svcConfig.executeCommand, this.otwparams);
         //check BusyStatus
         this.pollBusyStatus();
         console.log("OTW Consolidation Completed for " + this.vuData.binderLocatorId);
      }
   }

   pollBusyStatus() {
      //check if otw is busy
      let busy, scriptBusy;
      do {
         //Keepalive
         apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams);
         //otwBusyStatus
         let result = apiCalls.MakeRequest(svcConfig.otwBusyStatus, this.otwparams);
         busy = result.otwBusyStatus_data ? result.otwBusyStatus_data.indexOf("true") > -1 : true;
         console.log("The poll busy status is : " + busy);
         //getScriptRunStatusCheck
         result = apiCalls.MakeRequest(svcConfig.EfileErrorCheck, this.otwparams);
         scriptBusy = result.EfileErrorCheck_data ? result.EfileErrorCheck_data.indexOf("ScriptProcessing") > -1 : true;
         console.log(this.vuData.binderLocatorId + " => Busy Status :" + busy + " | Script Status :" + scriptBusy);
         sleep(15);
      } while (busy == true && scriptBusy == true);
   }

   efileStatusId_GST_1040() {
      let scriptid;
      let scriptidval;
      for (var i = 0; i < 1; i++) {
         do {
            console.log("In the status id function");
            var jobId = this.vuData.jobIds[i];
            //get the job status
            svcConfig.EfileStatusId.dynamicValues = { JobId: jobId };
            let result = apiCalls.MakeRequest(svcConfig.EfileStatusId, this.otwparams);
            console.log(this.vuData.binderLocatorId + " job id=> " + jobId + " status id=> " + result.EfileStatusId_data.StatusId);
            scriptid = result.EfileStatusId_data.StatusId == 2 ? "efile Creation Success  : " : result.EfileStatusId_data.StatusId == -1 ? "efile creation failed " : "Efile creation still in progress";
            // this.vuData.efileScriptId = scriptid;
            scriptidval = result.EfileStatusId_data.StatusId
            console.log("the status of efile is :" + scriptid);
            if (scriptidval == -1) {
               //Services.responseAssertions(result,svcConfig.EfileStatusId,)
               break;
            }
            sleep(10);
         } while (scriptidval != 2)
         // console.log(this.vuData.efileScriptId);
      }
   }
   efileStatusId_federal() {
      let scriptid;
      let scriptidval;
      if (this.vuData.jobIds.length > 0) {
         //  for (var i = 0; i < this.vuData.efileCount - 1; i++) {
         //let bindeIdval = this.vuData.binderId;
         //var statename = this.vuData.jobIds.split("_")[0];
         console.log(this.vuData.jobIds[0]);
         var jobId = this.vuData.jobIds[0];
         do {
            //get the job status
            svcConfig.EfileStatusId.dynamicValues = { JobId: jobId };
            let result = apiCalls.MakeRequest(svcConfig.EfileStatusId, this.otwparams);
            console.log(this.vuData.locatorId + " job id=> " + jobId + " status id=> " + result.EfileStatusId_data.StatusId);
            scriptid = result.EfileStatusId_data.StatusId == 2 ? "efile Creation Success  : " : result.EfileStatusId_data.StatusId == -1 ? "efile creation failed " : "Efile creation still in progress";
            // this.vuData.efileScriptId = scriptid;
            scriptidval = result.EfileStatusId_data.StatusId
            if (scriptidval == -1) {
               efileFailCounters.add(1);
               break;
            } else if (scriptidval == 2) {
               efilePassCounters.add(1);
            }
            sleep(30);
         } while (scriptidval != 2)
         console.log("Federal E-File Completed for " + this.vuData.binderLocatorId);
         // }
      } else {
         console.log(this.vuData.locatorId + "No jobids were created.");
      }
   }
   efileStatusId() {
      let scriptid;
      let scriptidval;
      if (this.vuData.jobIds.length > 0) {
         for (var i = 0; i < this.vuData.efileCount - 1; i++) {
            let bindeIdval = this.vuData.binderId;
            var statename = this.vuData.jobIds[i].split("_")[0];
            console.log(this.vuData.jobIds[i]);
            var jobId = this.vuData.jobIds[i].split("_")[1];
            do {
               //get the job status
               svcConfig.EfileStatusId.dynamicValues = { JobId: jobId };
               let result = apiCalls.MakeRequest(svcConfig.EfileStatusId, this.otwparams);
               console.log(this.vuData.locatorId + "job id=>" + jobId + "status id=>" + result.EfileStatusId_data.StatusId);
               scriptid = result.EfileStatusId_data.StatusId == 2 ? "efile Creation Success  : " : result.EfileStatusId_data.StatusId == -1 ? "efile creation failed " : "Efile creation still in progress";
               // this.vuData.efileScriptId = scriptid;
               scriptidval = result.EfileStatusId_data.StatusId
               if (scriptidval == -1) {
                  efileFailCounters.add(1);
                  break;
               } else if (scriptidval == 2) {
                  efilePassCounters.add(1);
               }
               sleep(30);
            } while (scriptidval != 2)
         }
      } else {
         console.log(this.vuData.locatorId + "No jobids were created.");
      }
   }
   /**
   * Create State EFile
   */
   createStateEfile() {
      if (this.vuData.runStateEfile == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         console.log("State E-File started for " + this.vuData.binderLocatorId + " non 1040 binder");
         let taxReturnType = this.vuData.binderTaxReturnType.includes("1120") ? "1120" : this.vuData.binderTaxReturnType.includes("1065") ? "1065" : "1040";
         let metadata = efileData[this.application][taxReturnType];

         svcConfig.getScreenData.dynamicValues = {
            area: metadata.enableStates.area,
            screen: metadata.enableStates.screen,
         }
         apiCalls.MakeRequest(svcConfig.getScreenData, this.otwparams);
         svcConfig.navtree.dynamicValues = {
            area: metadata.enableStates.area,
            screen: metadata.enableStates.screen,
         }
         apiCalls.MakeRequest(svcConfig.navtree, this.otwparams);

         //Enable All states
         metadata.enableStates.command1.forEach((cmd) => {
            svcConfig.executeCommand.dynamicValues = {
               area: metadata.enableStates.area,
               screen: metadata.enableStates.screen,
               field: metadata.enableStates.script,
               command1: cmd,
            };

            //Activate states
            apiCalls.MakeRequest(svcConfig.executeCommand, this.otwparams, {}, { testName: "Enable States" });
            console.log("Activated states for " + this.vuData.binderLocatorId + " non 1040 binder");
            //KeepAlive
            apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams);
            //wait for busy status
            if (this.vuData.newEfileFlow == "FALSE")
               this.pollBusyStatus();
            //do full recompute after state activation
            apiCalls.MakeRequest(svcConfig.fullRecompute, this.otwparams, {});
            //wait for busy status
            if (this.vuData.newEfileFlow == "FALSE")
               this.pollBusyStatus();
            sleep(3);
         });
         //KeepAlive
         apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams);
         //randomize array before doing Efile
         var states = common.randomizeArray(metadata.state["states_" + this.vuData.taxYear]);
         var allStateJobIds = [];
         //loop for states
         for (let i = 0; i < this.vuData.efileCount; i++) {
            try {
               let start = new Date();

               console.log(`Efiling Status for state ${states[i].name} (${states[i].code})`);

               //if new flow 
               if (this.vuData.newEfileFlow == "TRUE") {
                  console.log("In the new flow");
                  //get the job id
                  svcConfig.EfileJobId.dynamicValues = { area: metadata.state.area, screen: metadata.state.screen, field: states[i].code };
                  // let efileResult = apiCalls.MakeRequest(svcConfig.EfileJobId, this.otwparams, null, { testName: "get Efile job id" });
                  var url = apiCalls.actualUrl(svcConfig.EfileJobId);
                  var response = apiCalls.chooseServiceCall(svcConfig.EfileJobId.method, url, this.otwparams, null);
                  console.log("the efile result is :" + response.status);
                  if (response.status == 200) {
                     var scriptExStatus = "";
                     var jobid = null;
                     do {
                        let efileScriptResult = apiCalls.MakeRequest(svcConfig.EfileScriptStatus, this.otwparams, null, { testName: "get Efile script status" });
                        scriptExStatus = efileScriptResult.EfileScriptStatus_data.Status;
                        console.log("the script status is : " + scriptExStatus);
                        jobid = efileScriptResult.EfileScriptStatus_data.JobId;
                        sleep(2);
                     } while (scriptExStatus != "ScriptProcessingComplete")

                     if (jobid != null) {
                        console.log("The efile job id is: " + jobid);
                        var state_jobid = states[i].name + "_" + jobid
                        allStateJobIds.push(state_jobid);
                     }
                     this.vuData.jobIds = allStateJobIds;
                  } else {
                     console.log("The efile for state" + states[i].name + " with state code " + states[i].code + "failed with response code:" + response.status);
                  }
                  //KeepAlive
                  apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams);

               } else {
                  console.log("In the old flow");
                  //do state efile
                  svcConfig.executeCommand.dynamicValues = { area: metadata.state.area, screen: metadata.state.screen, field: states[i].code, command1: 0 };
                  let result = apiCalls.MakeRequest(svcConfig.executeCommand, this.otwparams, null, { testName: "Create State Efile" });
                  console.log(`Efiling Status for state ${states[i].name} (${states[i].code}) is :- ${result.executeCommand_data}`);
                  //KeepAlive
                  apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams);
                  //messageBox
                  apiCalls.MakeRequest(svcConfig.messageBox, this.otwparams);
                  //wait for busy status
                  this.pollBusyStatus();
               }
               let end = new Date();
               stateEfile.add(((end.getTime() - start.getTime()) / 1000).toFixed(2));
            } catch (e) {
               console.log(`Error Occured while doing state E-File for State ${states[i].name} with code ${states[i].code}`);
               console.log(e);
            }
         } //end loop for states
         if (this.vuData.newEfileFlow == "TRUE") {
            console.log("All the job ids are :" + allStateJobIds);
            this.efileStatusId();
         }
         console.log("State E-File Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * create Federal Efile
    */
   createFederalEfile() {

      var fedJobIds = [];

      let start = new Date();
      let taxReturnType = this.vuData.binderTaxReturnType.includes("1120") ? "1120" : this.vuData.binderTaxReturnType.includes("1065") ? "1065" : "1040";
      var metadata = efileData[this.application][taxReturnType];
      if (this.vuData.runFederalEfile == "TRUE" && this.vuData.locatorClosed != "TRUE" && this.vuData.newEfileFlow != "TRUE") {
         console.log("Federal E-File started for " + this.vuData.binderLocatorId);
         svcConfig.executeCommand.dynamicValues = { area: metadata.federal.area, screen: metadata.federal.screen, field: metadata.federal.script, command1: 0 };
         //Federal Efile
         apiCalls.MakeRequest(svcConfig.executeCommand, this.otwparams, null, { testName: "Create Federal Efile" });
         //keepAlive
         apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams);
         //check busy Status
         if (this.vuData.newEfileFlow == "FALSE")
            this.pollBusyStatus();
         let end = new Date();
         fedEfile.add(((end.getTime() - start.getTime()) / 1000).toFixed(2));

      } else if (this.vuData.runFederalEfile == "TRUE" && this.vuData.locatorClosed != "TRUE" && this.vuData.newEfileFlow == "TRUE") {
         console.log("In the new flow for federal efile");
         //get the job id
         svcConfig.EfileJobId.dynamicValues = { area: metadata.federal.area, screen: metadata.federal.screen, field: metadata.federal.script };
         // let efileResult = apiCalls.MakeRequest(svcConfig.EfileJobId, this.otwparams, null, { testName: "get Efile job id" });
         var url = apiCalls.actualUrl(svcConfig.EfileJobId);
         var response = apiCalls.chooseServiceCall(svcConfig.EfileJobId.method, url, this.otwparams, null);
         console.log("the efile result is :" + response.status);
         if (response.status == 200) {
            var scriptExStatus = "";
            var jobid = null;
            do {
               let efileScriptResult = apiCalls.MakeRequest(svcConfig.EfileScriptStatus, this.otwparams, null, { testName: "get federal efile script status" });
               scriptExStatus = efileScriptResult.EfileScriptStatus_data.Status;
               console.log("the script status is : " + scriptExStatus);
               jobid = efileScriptResult.EfileScriptStatus_data.JobId;
               sleep(2);
            } while (scriptExStatus != "ScriptProcessingComplete")

            if (jobid != null) {
               console.log("The efile job id is: " + jobid);
               //var jobid = "federal" + "_" + jobid
               fedJobIds.push(jobid);
            }
            this.vuData.jobIds = fedJobIds;
         }
      }
      if (this.vuData.runFederalEfile == "TRUE" && this.vuData.locatorClosed != "TRUE" && this.vuData.newEfileFlow == "TRUE") {
         console.log("The federal job id is :" + fedJobIds);
         this.efileStatusId_federal();
      }

   }

   createEfile_GST() {
      let start = new Date();

      if (this.vuData.runStateEfile == "TRUE" && this.vuData.locatorClosed != "TRUE" && this.vuData.binderTaxReturnType.includes("1040")) {
         //efilemetada
         console.log("Starting gst efile for " + this.vuData.binderLocatorId);
         let noOfPutCalls = 0;
         let tt = this.vuData.binderTaxReturnType.includes("1120") ? "1120" : this.vuData.binderTaxReturnType.includes("1065") ? "1065" : "1040";
         var efiledata = common.randomizeArray(efilemetada[this.application + "_" + tt]);
         console.log("the value of tt : " + tt + " the application is :" + this.application);
         let allStateJobIds = [];
         let metadata = efileData[this.application][tt];
         for (let i = 0; i < this.vuData.efileCount; i++) {
            efiledata.forEach((x) => {
               svcConfig.organizerdata.dynamicValues = { area: x.area, screen: x.screen };
               apiCalls.MakeRequest(svcConfig.organizerdata, this.otwparams);
               svcConfig.updateScreenData.dynamicValues = { area: x.area, screen: x.screen };
               console.log("the length of the states is : " + x.metadata.length);
               var randomIndex = common.getRandomIndex(x.metadata.length);
               console.log("the random index is " + randomIndex);

               var y = x.metadata[randomIndex];
               y["value"] = "0";
               y["showClientValidationError"] = false;
               y["clientValidationError"] = null;
               y["isDirty"] = true;
               console.log("Put Calls for eorg" + y["eorg"]);
               apiCalls.MakeRequest(svcConfig.updateScreenData, this.otwparams, JSON.stringify(y));
               sleep(3);
            });
         } //for loop close
         apiCalls.MakeRequest(svcConfig.fullRecompute, this.otwparams, JSON.stringify({}));
         // svc.Session.LogMessage(["Done Executing PUT Calls"], { putCalls: noOfPutCalls });
         console.log("Completed udpating the states checkboxes" + this.vuData.binderLocatorId);

         console.log(" E-File started for GST 1040 : " + this.vuData.binderLocatorId);

         if (this.vuData.newEfileFlow == "TRUE") {
            console.log("In the new flow");
            //get the job id
            svcConfig.EfileJobId.dynamicValues = { area: metadata.state.area, screen: metadata.state.screen, field: metadata.state.script };
            let efileResult = apiCalls.MakeRequest(svcConfig.EfileJobId, this.otwparams, null, { testName: "get Efile job id" });

            console.log("The efile job id is: " + efileResult.EfileJobId_data.JobId);
            // var state_jobid = states[i].name + "_" + efileResult.EfileJobId_data.JobId
            var state_jobid = efileResult.EfileJobId_data.JobId
            allStateJobIds.push(state_jobid);
            this.vuData.jobIds = allStateJobIds;
            //KeepAlive
            apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams);

         } else {
            console.log("In the old flow");
            //do state efile
            svcConfig.executeCommand.dynamicValues = { area: metadata.state.area, screen: metadata.state.screen, field: metadata.state.script, command1: 0 };
            let result = apiCalls.MakeRequest(svcConfig.executeCommand, this.otwparams, null, { testName: "Create State Efile" });
            console.log(`Efiling Status  is :- ${result.executeCommand_data}`);
            //KeepAlive
            apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams);
            this.pollBusyStatus();
            //messageBox
            apiCalls.MakeRequest(svcConfig.messageBox, this.otwparams);
            console.log("Clicked on the message box");
            //wait for busy status
         }

         if (this.vuData.newEfileFlow == "TRUE") {
            console.log("All the job ids are :" + allStateJobIds);
            this.efileStatusId_GST_1040();
         }
      } else if (this.vuData.runStateEfile == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         this.createStateEfile();
      }
      let end = new Date();
      stateEfile.add(((end.getTime() - start.getTime()) / 1000).toFixed(2));
   }
   /**
    * Run Diagnostics
    */
   runDiagnostics() {
      if (this.vuData.runDiagnostics == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         console.log("Loading Diagnnostics started for " + this.vuData.binderLocatorId);
         let start = new Date();
         //keepAlive
         apiCalls.MakeRequest(svcConfig.keepAlive, this.otwparams);
         //getDiagnosticsData
         apiCalls.MakeRequest(svcConfig.diagnostics, this.otwparams);
         //check busy status
         this.pollBusyStatus();
         let end = new Date();
         diag.add(((end.getTime() - start.getTime()) / 1000).toFixed(2));
         console.log("Loading Diagnostics Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * EFileError check
    */
   efileErrorCheck() {
      if (this.vuData.runEfileErrorCheck == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         console.log("E-File Error Check started for " + this.vuData.binderLocatorId);
         let start = new Date();
         let taxReturnType = this.vuData.binderTaxReturnType.includes("1120") ? "1120" : "1065";
         var metadata = efileData[this.application][taxReturnType];
         //getScreenData
         svcConfig.getScreenData.dynamicValues = { area: metadata.errorCheck.area, screen: metadata.errorCheck.screen };
         apiCalls.MakeRequest(svcConfig.getScreenData, this.otwparams);
         //EFile Error Check
         svcConfig.executeCommand.dynamicValues = { area: metadata.errorCheck.area, screen: metadata.errorCheck.screen, field: metadata.errorCheck.script, command1: 0 };
         apiCalls.MakeRequest(svcConfig.executeCommand, this.otwparams, null, { testName: "Efile Error Check" });
         //check busy status
         this.pollBusyStatus();
         let end = new Date();
         eFileErrorCheck.add(((end.getTime() - start.getTime()) / 1000).toFixed(2));
         console.log("E-File Error Check Completed for " + this.vuData.binderLocatorId);
      }
   }

   /**
    * Closes Locator
    */
   closeLocator() {
      if (this.vuData.launchOTW == "TRUE" && this.vuData.locatorClosed != "TRUE") {
         //remove session
         console.log("Close Locator started for " + this.vuData.binderLocatorId);
         svcConfig.deleteSession.dynamicValues = { vu: __VU };
         apiCalls.MakeRequest(svcConfig.deleteSession, common.getSimpleParams());
         apiCalls.MakeRequest(svcConfig.closeLocator, this.otwparams);
         this.vuData.locatorClosed = "TRUE";
         console.log("Close Locator Completed for " + this.vuData.binderLocatorId);
         sleep(40);
      }
   }

   /**
    * GST Open Token
    */
   gstInit() {
      console.log("GST Initialization started for " + this.vuData.binderLocatorId);
      //Generate Open Token
      var result = apiCalls.MakeRequest(svcConfig.gstOpenToken, this.gstParams);
      this.gstParams.headers["Authorization"] = "OpenToken " + result.gstOpenToken_data.replace(/\"/g, "");
      this.gstParams.headers["Content-Type"] = "application/json";
      //Get the appserver IP
      svcConfig.gstAppSelector.dynamicValues = { locator: this.vuData.binderLocatorId, taxApp: this.vuData.taxApp, yearLast2: this.vuData.taxYear.slice(-2) };
      result = apiCalls.MakeRequest(svcConfig.gstAppSelector, this.gstParams);
      var ipAddress = result.gstAppSelector_data.IPAddress;
      let payload = {
         LoginId: this.vuData.username,
         Locator: this.vuData.binderLocatorId,
         TaxType: this.vuData.taxType ? this.vuData.taxType : "C",
         taxYear: this.vuData.taxYear,
         account: this.vuData.account,
         Firm: this.vuData.firm,
         userCenter: this.vuData.center,
         nameSpace: this.vuData.nameSpace,
         appServer: ipAddress,
      };
      //Cookie Blob
      result = apiCalls.MakeRequest(svcConfig.gstCookieBlob, this.gstParams, JSON.stringify(payload));
      svcConfig.openLocator.dynamicValues = { openToken: result.gstCookieBlob_data.encryptedString, year: this.vuData.taxYear, isOneSource: "False" };
      //Open Locator
      delete this.otwparams.headers.Authorization;
      result = apiCalls.MakeRequest(svcConfig.openLocator, this.otwparams, null, { binderId: this.vuData.binderLocatorId });
      if (result.status != 200) {
         this.vuData.locatorClosed = "TRUE";
      } else {
         this.vuData.locatorClosed = "FALSE";
      }
      this.vuData.AuthToken = result.openLocator_data.AuthToken;
      this.vuData.locatorToken = result.openLocator_data.Token;
      this.vuData.LocatorId = result.openLocator_data.LocatorId;
      this.otwparams.headers.Authorization = "Bearer " + this.vuData.AuthToken.replace(/\"/g, "");
      this.otwparams.headers["locator-token"] = this.vuData.locatorToken;
      svcConfig.createSession.dynamicValues = { vu: __VU };
      payload = { params: this.otwparams, cookies: result.cookies };
      apiCalls.MakeRequest(svcConfig.createSession, common.getSimpleParams(), JSON.stringify(payload));
      console.log("GST Initialization Completed for " + this.vuData.binderLocatorId);
   }

   /**
    * Full Recompute
    */
   fullRecompute() {
      if (this.vuData.runFullCompute == "TRUE") {
         //Full Recompute
         console.log("Full Recompute started for " + this.vuData.binderLocatorId);
         apiCalls.MakeRequest(svcConfig.fullRecompute, this.otwparams, JSON.stringify({}));
         this.pollBusyStatus();
         console.log("Full Recompute Completed for " + this.vuData.binderLocatorId);
      }
   }

   navigateScreens() {
      if (this.vuData.getScreenData == "TRUE") {
         noOfRequests = 0;
         console.log("Starting navigate screen Calls for " + this.vuData.binderLocatorId);
         //call 0-0
         var MainNodeCall = apiCalls.MakeRequest(svcConfig.MainNode, this.otwparams);
         //get Organizer data first
         let organizerData = MainNodeCall.MainNode_data[0]; //organizerData
         this.NodeAction(organizerData.Items);
      }
   }

   ScreenCall(x) {
      try {
         if (x.Area > 0 || x.Screen > 0) {
            svcConfig.StaticContent.dynamicValues = { area: x.Area, screen: x.Screen, binderTaxReturnTypeId: this.vuData.binderTaxReturnType };
            //navtree
            svcConfig.navtree.dynamicValues = { area: x.Area, screen: x.Screen };
            apiCalls.MakeRequest(svcConfig.navtree, this.otwparams);
            //Static content
            apiCalls.MakeRequest(svcConfig.StaticContent, this.otwparams);
            //getScreenData
            svcConfig.getScreenData.dynamicValues = { area: x.Area, screen: x.Screen };
            apiCalls.MakeRequest(svcConfig.getScreenData, this.otwparams);
            console.log("Opened page => " + x.Name + "area and screen codes as : " + x.Area + " " + x.Screen);
            noOfRequests++;
         } else {
            console.log("encountered Node with area and screen as 0 nodeName:- " + x.Name);
         }
      } catch (e) {
         console.log("Error Occured with Node " + JSON.stringify(x));
      }
   }

   ExpandingPage(x) {
      // console.log("Expanding Page => " + x.Name);
      svcConfig.NavigateNode.dynamicValues = { area: x.Area, screen: x.Screen, nodeId: x.Id, parentNodeId: x.ParentId };
      var response = apiCalls.MakeRequest(svcConfig.NavigateNode, this.otwparams);
      return response;
   }

   NodeAction(NodeData) {
      console.log("the no of requests is : " + noOfRequests);
      NodeData.forEach((y) => {
         if (noOfRequests < 50) {
            if (y.Screen == 0 && y.Area == 0) {
               //visiting the Node
               var response = this.ExpandingPage(y);
               NodeData = response.NavigateNode_data;
               this.NodeAction(NodeData);
            } else {
               //if area and screen are not 0
               this.ScreenCall(y);
            }
         }
      });
   }
}
